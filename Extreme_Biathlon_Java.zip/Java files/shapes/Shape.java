package shapes;

import javax.swing.*;
import java.awt.*;

public abstract class Shape extends JComponent {
    public int xCoord;
    public int yCoord;
    public int width;
    public int height;

    public Shape (){
        super();
    }

    public abstract void make(Graphics2D g);
}
