package shapes;

import java.awt.*;
import java.awt.geom.AffineTransform;

public class Log extends Shape {
    double velocity;

    // creates obstacle object that can have data dynamically parsed into it
    public Log(Integer xCoord, Integer yCoord, Integer width, Integer height, double velocity) {
        this.xCoord = xCoord;
        this.yCoord = yCoord;
        this.width = width;
        this.height = height;
        this.velocity = velocity;
    }

    public void make(Graphics2D g){ // designs obstacle
        AffineTransform l = g.getTransform();
        g.translate(this.xCoord, this.yCoord);
        g.setColor(Color.orange);

        g.fillRect(0,0,this.width,this.height);
        g.setTransform(l);

    }

    public void updateLogPosition() { // Method to update car position
        // keeps the car object within the boundaries of the playable game view
        if (this.xCoord < 0 || this.xCoord > (400 - this.width)) {
            velocity = -velocity;
        }

        xCoord += velocity;
    }

    // creates the border boundary of the obstacle object
    public Rectangle lbounds(){
        return (new Rectangle(this.xCoord, this.yCoord, this.width, this.height));
    }

}
