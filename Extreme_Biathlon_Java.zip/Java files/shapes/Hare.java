package shapes;

import myGame.Movement;

import java.awt.*;
import java.awt.geom.AffineTransform;

public class Hare extends Shape { // creates character object
    public int distanceX;
    public int distanceY;
    public int lives;
    Movement movement;

    int diameter = 20;
    int xBoundary = 400;
    int yBoundary = 400;

    // creates character object that can have data dynamically parsed into it
    public Hare(Integer xCoord, Integer yCoord, Integer width, Integer height,
                int distanceX, int distanceY, Movement movement, int lives)
    {
        this.xCoord = xCoord;
        this.yCoord = yCoord;
        this.width = width;
        this.height = height;
        this.distanceX = distanceX;
        this.distanceY = distanceY;
        this.movement = movement;
        this.lives = lives;
    }


    public void make(Graphics2D g){ // designs character
        AffineTransform h = g.getTransform();
        g.translate(this.xCoord, this.yCoord);
        g.setColor(Color.white);

        g.fillOval(0,0,this.width,this.height);
        g.setTransform(h);
    }

    public void updateHarePosition() { // Method to update hare position
        // keeps the character within the boundaries of the playable game view
        if (this.xCoord < 0) {
            this.xCoord = 0;
        } else if ((this.xCoord + diameter) > xBoundary) {
            this.xCoord = xBoundary - diameter;
        }
        if (this.yCoord < 0) {
            this.yCoord = 0;
        } else if ((this.yCoord + diameter) > yBoundary) {
            this.yCoord = yBoundary - diameter;
        }

        // determines the speed of the character in each direction
        if (movement.getUp()) {
            this.yCoord += -3;
        }
        if (movement.getDown()) {
            this.yCoord += 3;
        }
        if (movement.getRight()) {
            this.xCoord += 3;
        }
        if (movement.getLeft()) {
            this.xCoord += -3;
        }
    }

    // creates the border boundary of the character object
    public Rectangle hbounds(){
        return (new Rectangle(this.xCoord, this.yCoord, this.width, this.height));
    }
}
