package utilities;

// code copied from Simon Lucas
// code copied by Udo Kruschwitz
// code used as template by K'Ci Beckford

import myGame.GameView;
import playGame.Game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Collections;
import java.util.LinkedList;

import static java.lang.Boolean.FALSE;
import static playGame.Game.score;

public class JEasyFrame extends JFrame { // Class creates application window using JFrame
    public Component comp;
    public static JLabel space;
    public static JLabel lives;

    public static LinkedList<String> board = new LinkedList<>();

    public JEasyFrame(Component comp, String title) {
        super(title); // implements program title
        this.comp = comp;
        getContentPane().add(BorderLayout.CENTER, comp);
        pack();

        // instructions for the player
        JTextArea info = new JTextArea("To register your score, please click \non the 'Update Leaderboard' button.");
        JButton viewScore = new JButton("Update Leaderboard"); // Button to update leaderboard file
        space = new JLabel(); // Area to view score
        lives = new JLabel(); // Area to view lived
        JPanel panel = new JPanel();
        JPanel board = new JPanel();
        Box box = Box.createVerticalBox();
        space.setOpaque(FALSE);
        lives.setOpaque(FALSE);
        info.setOpaque(FALSE);

        repaint();

        panel.setPreferredSize(new Dimension(220, 100)); // sets size of JPanel
        board.setPreferredSize(new Dimension(250, 300));

        info.setPreferredSize(new Dimension(200, 50));
        viewScore.setPreferredSize(new Dimension(170, 30));

        panel.add(info); // adds data to JPanel
        panel.add(viewScore);
        panel.add(box);
        box.add(space);
        box.add(lives);

        BorderLayout borderLayout = new BorderLayout(); // sets layout
        setLayout(borderLayout);
        borderLayout.setVgap(50);

        add(panel, borderLayout.EAST);

        this.setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        viewScore.addActionListener(new ActionListener(){ // Applies actionlistener to button
            @Override
            public void actionPerformed(ActionEvent e) {
                add(board, borderLayout.EAST); // adds the panel on button click
                try {
                    GameView.inGame = false; // sets the ingame variable to false on click
                    getScoreFile(); // accesses the score method on click
                    leaderboard(); // accesses the leaderboard method on click
                } catch (FileNotFoundException e1) { // if file not found, act exception
                    e1.printStackTrace();
                } catch (IOException e2) { // if null, catch exception
                    e2.printStackTrace();
                }
            }
        });
    }

    private void updateScoreActionPerformed(ActionEvent e) { // method to update the players lives in real time
        Game ns = new Game(); // creates new game instance
        ns.updateScore(lives); // references method in Game class to retrieve number of lives
    }

    private void updateLivesActionPerformed(ActionEvent e) { // method to update the player score in real time
        Game nl = new Game();
        nl.updateLives(space); // references method in Game class to retrieve player score
    }

    public static void getScoreFile() throws FileNotFoundException { // creates and retrieves text file wit hscores
        String fn = "leaderboard.txt"; // file name
        File fileName = new File(fn); // creates file instance

        if (fileName.exists()) { // appends new score into the created file
            try (FileWriter fWriter = new FileWriter(fn, true);
                BufferedWriter bWriter = new BufferedWriter(fWriter);
                PrintWriter scores = new PrintWriter(bWriter)) {
                    scores.println(score);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        } else { // file doesn't exist, it is created first the n the score is appended
            PrintWriter scores = new PrintWriter("leaderboard.txt");
            scores.println(score);
            scores.close();
        }
    }

    public static void leaderboard() throws IOException { // reads the score file
        FileInputStream fStream = new FileInputStream("leaderboard.txt");
        BufferedReader br = new BufferedReader(new InputStreamReader(fStream));
        String strLine;

        while ((strLine = br.readLine()) != null){
            board.add(strLine);

            // sorts all scores in the file by largest first
            Collections.sort(board);
            Collections.reverse(board);

            // displays only the top 10 scores
            if (board.size() > 10){
                board.remove(board.size() - 1);
            }
        }
        br.close();
    }
}
