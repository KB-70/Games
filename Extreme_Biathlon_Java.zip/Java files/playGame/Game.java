package playGame;

import myGame.GameView;
import myGame.Movement;
import shapes.Car;
import shapes.Hare;
import shapes.Log;
import shapes.Shape;
import utilities.JEasyFrame;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static myGame.GameView.inGame;

public class Game { // the Game class
    private GameView gameView;
    public List<Shape> objects;
    private boolean collision = false;
    boolean newScore = false;
    public int numLives;
    public static int score;

    // Movement object allowing character object to move
    public Movement movement = new Movement(this);

    // character object controlled by the user
    private Hare rabbit = new Hare(200, 380, 20,
            20, 0, 20, movement, 3);

    // obstacle objects for the user to avoid
    private Car carA = new Car(340, 220, 60, 40, -2.2);
    private Car carB = new Car(0, 260, 60, 40, 6);
    private Car carC = new Car(340, 300, 60, 40, -3.1);
    private Car carD = new Car(0, 340, 60, 40, 2.6);

    private Log logA = new Log(0, 20, 80, 20, 2);
    private Log logB = new Log(0, 40, 40, 20, 2.9);
    private Log logC = new Log(300, 60, 100, 20, -3.2);
    private Log logD = new Log(0, 80, 60, 20, 1);
    private Log logE = new Log(340, 100, 40, 20, -2);
    private Log logF = new Log(0, 120, 60, 20, 5);
    private Log logG = new Log(340, 140, 40, 20, -2.8);
    private Log logH = new Log(0, 160, 80, 20, 2.8);


    public Game() {
        objects = new ArrayList<>(); // list used to hole all objects

        objects.add(rabbit); // object added to list

        objects.add(carA);
        objects.add(carB);
        objects.add(carC);
        objects.add(carD);

        objects.add(logA);
        objects.add(logB);
        objects.add(logC);
        objects.add(logD);
        objects.add(logE);
        objects.add(logF);
        objects.add(logG);
        objects.add(logH);

        colorGrid(); // initialises the method that draws the game environment

    }

    public void colorGrid() { // Method to draw game environment
        Random r = new Random();
        int w = 20;
        int h = 20;
        int[][] a = new int[w][h];
        for (int i = 0; i < w; i++) {
            for (int j = h / 2; j < h; j++) {
                a[i][j] =
                        r.nextInt(GameView.colors.length); // applies characteristics made in GameView class
            }
        }

        numLives = rabbit.lives; // assigns object feature to variable
        score = 0; // sets default score variable

        gameView = new GameView(a, this); // puts game environment in variable
        new JEasyFrame(gameView, "1600965"); // applies game environment to JFrame window

        while (numLives > 0) {
            this.update(); // continuously run game until number of lives equals 0
            gameView.repaint(); // constantly redraws objects
            try {
                Thread.sleep(25); // time delay for redrawing objects
                if (collision) { // if statement that resets character to starting position if there is a collision
                    rabbit.xCoord = 200;
                    rabbit.yCoord = 380;
                    collision = false;
                }
                if (newScore) { // if statement that resets character to starting position if player reaches the end
                    rabbit.xCoord = 200;
                    rabbit.yCoord = 380;
                    newScore = false;
                }
            } catch (Exception e) {
                System.out.println("Failed");
            }
        }
        if (numLives == 0) { // if statement closes playable view
            inGame = false;
        }
    }

    public void update() { // Method used to continuously update game state

        rabbit.updateHarePosition();

        carA.updateCarPosition();
        carB.updateCarPosition();
        carC.updateCarPosition();
        carD.updateCarPosition();

        logA.updateLogPosition();
        logB.updateLogPosition();
        logC.updateLogPosition();
        logD.updateLogPosition();
        logE.updateLogPosition();
        logF.updateLogPosition();
        logG.updateLogPosition();
        logH.updateLogPosition();

        collision(); // initialises the collision Method
        updateScore(JEasyFrame.space); // initialises updateScore Method
        updateLives(JEasyFrame.lives); // initialises updateLives Method
    }

    public void collision() { // Method used to check if character collides with object in game
        Rectangle hare = rabbit.hbounds();

        Rectangle car1 = carA.cbounds();
        Rectangle car2 = carB.cbounds();
        Rectangle car3 = carC.cbounds();
        Rectangle car4 = carD.cbounds();

        Rectangle log1 = logA.lbounds();
        Rectangle log2 = logB.lbounds();
        Rectangle log3 = logC.lbounds();
        Rectangle log4 = logD.lbounds();
        Rectangle log5 = logE.lbounds();
        Rectangle log6 = logF.lbounds();
        Rectangle log7 = logG.lbounds();
        Rectangle log8 = logH.lbounds();

        if (hare.intersects(car1)){
            // the character intersects the border boundary of this object, the collision state changes
            collision = true;
        } else if (hare.intersects(car2)) {
            collision = true;
        } else if (hare.intersects(car3)) {
            collision = true;
        } else if (hare.intersects(car4)) {
            collision = true;
        } else if (hare.intersects(log1)){
            collision = true;
        } else if (hare.intersects(log2)) {
            collision = true;
        } else if (hare.intersects(log3)) {
            collision = true;
        } else if (hare.intersects(log4)) {
            collision = true;
        } else if (hare.intersects(log5)) {
            collision = true;
        } else if (hare.intersects(log6)) {
            collision = true;
        } else if (hare.intersects(log7)) {
            collision = true;
        } else if (hare.intersects(log8)) {
            collision = true;
        } else {
            collision = false;
        }
    }

    public void updateScore(JLabel sLabel) { // Method used to update score in real time
        sLabel.setText("Score: " + String.valueOf(score));
        if (rabbit.yCoord < 1) {
            newScore = true;
            score = score + 1;
            sLabel.setText("Score: " + String.valueOf(score));
        }
    }

    public void updateLives(JLabel lLabel) { // Method used to update players lives in real time
        lLabel.setText("Lives: " + String.valueOf(numLives));
        if (collision) {
            numLives = numLives - 1;
            lLabel.setText("Lives: " + String.valueOf(numLives));
        }
    }
}
