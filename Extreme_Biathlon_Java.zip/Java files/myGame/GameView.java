package myGame;

// code copied from Simon Lucas
// code copied by Udo Kruschwitz
// code used as template by K'Ci Beckford


import playGame.Game;
import shapes.Shape;
import javax.swing.*;
import java.awt.*;
import static java.awt.Color.*;
import static playGame.Game.score;
import static utilities.JEasyFrame.board;


// import all the Colors
public class GameView extends JComponent { // Class creates playable area for game
    public static Color[] colors =
            {black, green, blue, red,
                    yellow, magenta, pink, cyan};
    public static int[][] a;
    // sets size of area
    int w, h;
    static int wsize = 32;
    static int size = 20;

    public static Game game;

    public GameView(int[][] a, Game game) {

        this.game = game;
        this.a = a;
        w = a.length;
        h = a[0].length;
        addKeyListener(game.movement); // allows character object to move on playable area
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
    }

    public static boolean inGame = true; // sets the game state to playable

    @Override
    public void paintComponent(Graphics g) {
        if (inGame) {
            for (int i = 0; i < w; i++) {
                for (int j = 0; j < h; j++) {
                    // designs the playable area
                    g.setColor(green);
                    g.fill3DRect(i * size, 0 * size, size, size, true);
                    g.setColor(cyan);
                    g.fill3DRect(i * size, j * size, size, size, true);
                    g.setColor(yellow);
                    g.fill3DRect(i * size, 9 * size, size, size, true);
                    g.fill3DRect(i * size, 10 * size, size, size, true);
                    for (int k = 11; k < h; k++) {
                        g.setColor(lightGray);
                        g.fill3DRect(i * size, k * size,
                                size, size, true);
                    }
                    g.setColor(green);
                    g.fill3DRect(i * size, 19 * size, size, size, true);

                }
            }
            // draws all objects on playable area
            Graphics2D g2 = (Graphics2D) g;
            for (Shape shapes : game.objects) {
                shapes.make(g2);
                repaint();
            }
        }
        else { // playable area inactive, shows the leaderboard screen
            for (int i = 0; i < w; i++) {
                for (int j = 0; j < h; j++) {
                    g.setColor(black);
                    g.fillRect(i * size, j * size, size, size);
                    g.setColor(white);
                    g.setFont(new Font("TimesRoman", Font.PLAIN, 24));
                    g.drawString("Leaderboard", 130, 60);
                    g.setFont(new Font("TimesRoman", Font.PLAIN, 18));
                    g.drawString("Your Score: " + score, 140, 85);
                    int placement = 0;
                    for (String score : board) {
                        g.clearRect(400, 400, size, size);
                        placement += 20;
                        g.setColor(white);
                        g.setFont(new Font("TimesRoman", Font.PLAIN, 18));
                        g.drawString(score, 190, 100 + placement);
                        repaint();
                    }
                }
            }
        }
        repaint();
    }

    // sets size of window
    public Dimension getPreferredSize() {
       return new Dimension(w * wsize, h * size);
    }
}
