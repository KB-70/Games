package myGame;

import playGame.Game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Movement implements KeyListener { // Class to control movement of character object

    private Game gamePlay;
    boolean up = false; // boolean to determine if up key pressed
    boolean down = false; // boolean to determine if down key pressed
    boolean right = false; // boolean to determine if right key pressed
    boolean left = false; // boolean to determine if left key pressed

    public Movement(Game game){
        this.gamePlay = game; // makes playable in game
    }

    public boolean getUp() {
        return up;
    }

    public boolean getDown() {
        return down;
    }

    public boolean getRight() {
        return right;
    }

    public boolean getLeft() {
        return left;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_UP){
            up = true; // updates boolean when key pressed for up
        }
        if (code == KeyEvent.VK_DOWN){
            down = true; // updates boolean when key pressed for down
        }
        if (code == KeyEvent.VK_LEFT){
            left = true; // updates boolean when key pressed for left
        }
        if (code == KeyEvent.VK_RIGHT){
            right = true; // updates boolean when key pressed for right
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_UP){
            up = false; // updates boolean when key released for up
        }
        if (code == KeyEvent.VK_DOWN){
            down = false; // updates boolean when key released for down
        }
        if (code == KeyEvent.VK_LEFT){
            left = false; // updates boolean when key released for left
        }
        if (code == KeyEvent.VK_RIGHT){
            right = false; // updates boolean when key released for right
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}
}
